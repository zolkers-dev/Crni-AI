/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState, useRef } from "react";
import L from "leaflet";
import polyline from "@mapbox/polyline";
import { motion, AnimatePresence } from "motion/react";
import {
  Mic,
  MicOff,
  Send,
  Volume2,
  VolumeX,
  MapPin,
  Compass,
  Navigation,
  Sparkles,
  Sliders,
  RefreshCw,
  X,
  ChevronRight,
  Info,
  Map as MapIcon,
  MessageSquare,
  Terminal,
  Cpu,
  ShieldCheck,
  Zap,
  LogIn,
  LogOut,
  Github,
  MoreHorizontal,
  Palette,
  Trash2,
  Plus,
  Plane,
  Car,
  Hotel,
  Sun,
  Cloud,
  CloudRain,
  CloudLightning
} from "lucide-react";
import { ChatMessage, RoutingState, GeocodedLocation, CrniResponse, SavedLocation, ChatSession, ChatHistoryItem, UserPreferences } from "./types";
import {
  subscribeToAuth,
  signInWithGoogle,
  signInWithGithub,
  logOut,
  AuthUserProfile,
  isFirebaseLive,
  signInWithEmail,
  signUpWithEmail,
  saveUserPreferences,
  getUserPreferences
} from "./lib/firebase";

export const themeConfig = {
  cyan: {
    accentText: "text-cyan-400",
    accentTextMuted: "text-cyan-300",
    accentTextDark: "text-cyan-500",
    accentBg: "bg-cyan-500",
    accentBgHover: "hover:bg-cyan-400",
    accentBgDeep: "bg-cyan-600",
    accentBgDeepHover: "hover:bg-cyan-500",
    accentBgMuted: "bg-cyan-950/40",
    accentBgMutedHeader: "bg-cyan-950/80",
    accentBorder: "border-cyan-500",
    accentBorderMuted: "border-cyan-500/20",
    accentBorderLight: "border-cyan-500/30",
    accentBorderSubtle: "border-cyan-500/50",
    accentRing: "focus:border-cyan-500/80",
    hoverBorder: "hover:border-cyan-500",
    hoverText: "hover:text-cyan-400",
    hoverTextMuted: "hover:text-cyan-300",
    hoverBorderMuted: "hover:border-cyan-500/30",
    borderBtnHover: "hover:border-cyan-500/60 hover:text-cyan-400",
    tagGlow: "shadow-[0_0_8px_rgba(6,182,212,0.4)]",
    pulseDot: "bg-cyan-500",
    equalizer: "bg-cyan-500",
    equalizerMuted: "bg-cyan-400",
    equalizerDeep: "bg-cyan-600",
  },
  vampire: {
    accentText: "text-red-500",
    accentTextMuted: "text-red-400",
    accentTextDark: "text-red-650",
    accentBg: "bg-red-600",
    accentBgHover: "hover:bg-red-500",
    accentBgDeep: "bg-red-700",
    accentBgDeepHover: "hover:bg-red-600",
    accentBgMuted: "bg-red-950/40",
    accentBgMutedHeader: "bg-red-950/80",
    accentBorder: "border-red-600",
    accentBorderMuted: "border-red-600/20",
    accentBorderLight: "border-red-600/30",
    accentBorderSubtle: "border-red-500/50",
    accentRing: "focus:border-red-500/80",
    hoverBorder: "hover:border-red-500",
    hoverText: "hover:text-red-500",
    hoverTextMuted: "hover:text-red-400",
    hoverBorderMuted: "hover:border-red-500/30",
    borderBtnHover: "hover:border-red-500/60 hover:text-red-405",
    tagGlow: "shadow-[0_0_8px_rgba(239,68,68,0.4)]",
    pulseDot: "bg-red-500",
    equalizer: "bg-red-500",
    equalizerMuted: "bg-red-400",
    equalizerDeep: "bg-red-600",
  },
  forest: {
    accentText: "text-emerald-400",
    accentTextMuted: "text-emerald-300",
    accentTextDark: "text-emerald-500",
    accentBg: "bg-emerald-500",
    accentBgHover: "hover:bg-emerald-400",
    accentBgDeep: "bg-emerald-600",
    accentBgDeepHover: "hover:bg-emerald-500",
    accentBgMuted: "bg-emerald-950/40",
    accentBgMutedHeader: "bg-emerald-950/80",
    accentBorder: "border-emerald-500",
    accentBorderMuted: "border-emerald-500/20",
    accentBorderLight: "border-emerald-500/30",
    accentBorderSubtle: "border-emerald-500/50",
    accentRing: "focus:border-emerald-500/80",
    hoverBorder: "hover:border-emerald-500",
    hoverText: "hover:text-emerald-400",
    hoverTextMuted: "hover:text-emerald-300",
    hoverBorderMuted: "hover:border-emerald-500/30",
    borderBtnHover: "hover:border-emerald-500/60 hover:text-emerald-400",
    tagGlow: "shadow-[0_0_8px_rgba(16,185,129,0.4)]",
    pulseDot: "bg-emerald-500",
    equalizer: "bg-emerald-500",
    equalizerMuted: "bg-emerald-400",
    equalizerDeep: "bg-emerald-600",
  },
  chill: {
    accentText: "text-purple-400",
    accentTextMuted: "text-purple-300",
    accentTextDark: "text-purple-500",
    accentBg: "bg-purple-500",
    accentBgHover: "hover:bg-purple-400",
    accentBgDeep: "bg-purple-600",
    accentBgDeepHover: "hover:bg-purple-500",
    accentBgMuted: "bg-purple-950/40",
    accentBgMutedHeader: "bg-purple-950/80",
    accentBorder: "border-purple-500",
    accentBorderMuted: "border-purple-500/20",
    accentBorderLight: "border-purple-500/30",
    accentBorderSubtle: "border-purple-500/50",
    accentRing: "focus:border-purple-500/80",
    hoverBorder: "hover:border-purple-500",
    hoverText: "hover:text-purple-400",
    hoverTextMuted: "hover:text-purple-300",
    hoverBorderMuted: "hover:border-purple-500/30",
    borderBtnHover: "hover:border-purple-500/60 hover:text-purple-400",
    tagGlow: "shadow-[0_0_8px_rgba(168,85,247,0.4)]",
    pulseDot: "bg-purple-500",
    equalizer: "bg-purple-500",
    equalizerMuted: "bg-purple-400",
    equalizerDeep: "bg-purple-600",
  },
  kitty: {
    accentText: "text-pink-400",
    accentTextMuted: "text-pink-300",
    accentTextDark: "text-pink-500",
    accentBg: "bg-pink-500",
    accentBgHover: "hover:bg-pink-400",
    accentBgDeep: "bg-pink-600",
    accentBgDeepHover: "hover:bg-pink-500",
    accentBgMuted: "bg-pink-950/40",
    accentBgMutedHeader: "bg-pink-950/80",
    accentBorder: "border-pink-500",
    accentBorderMuted: "border-pink-500/20",
    accentBorderLight: "border-pink-500/30",
    accentBorderSubtle: "border-pink-500/50",
    accentRing: "focus:border-pink-500/80",
    hoverBorder: "hover:border-pink-500",
    hoverText: "hover:text-pink-400",
    hoverTextMuted: "hover:text-pink-300",
    hoverBorderMuted: "hover:border-pink-500/30",
    borderBtnHover: "hover:border-pink-500/60 hover:text-pink-400",
    tagGlow: "shadow-[0_0_8px_rgba(244,114,182,0.4)]",
    pulseDot: "bg-pink-500",
    equalizer: "bg-pink-500",
    equalizerMuted: "bg-pink-400",
    equalizerDeep: "bg-pink-600",
  }
};

// --- COMPONENT: TYPING EFFECT ---
const TypingEffect = ({ text, onComplete }: { text: string; onComplete?: () => void }) => {
  const [displayedText, setDisplayedText] = useState("");
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    setDisplayedText("");
    setCurrentIndex(0);
  }, [text]);

  useEffect(() => {
    if (currentIndex < text.length) {
      const timeout = setTimeout(() => {
        setDisplayedText((prev) => prev + text[currentIndex]);
        setCurrentIndex((prev) => prev + 1);
      }, Math.max(2, Math.min(25, Math.floor(Math.random() * 20)))); 
      return () => clearTimeout(timeout);
    } else if (onComplete) {
      const finishTimeout = setTimeout(onComplete, 300);
      return () => clearTimeout(finishTimeout);
    }
  }, [currentIndex, text]);

  return (
    <span className="relative">
      {displayedText}
      {currentIndex < text.length && (
        <span className="inline-block w-1.5 h-3.5 ml-1 bg-current animate-pulse align-middle" />
      )}
    </span>
  );
};

export default function App() {
  const [currentUser, setCurrentUser] = useState<AuthUserProfile | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);
  const [authEmail, setAuthEmail] = useState("");
  const [authPass, setAuthPass] = useState("");
  const [isAuthModeSignup, setIsAuthModeSignup] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  const [theme, setTheme] = useState<"cyan" | "vampire" | "forest" | "chill" | "kitty">(() => {
    const saved = localStorage.getItem("crni_agent_theme");
    return (saved as any) || "cyan";
  });
  const [isCustomizeOpen, setIsCustomizeOpen] = useState(false);
  const [preferredCurrency, setPreferredCurrency] = useState<string>(() => {
    return localStorage.getItem("crni_agent_currency") || "USD";
  });

  const handleGoogleSignIn = async () => {
    try {
      setAuthError(null);
      const user = await signInWithGoogle();
      setMessages((prev) => [
        ...prev,
        {
          id: Math.random().toString(),
          sender: "crni",
          text: `Access granted, Master ${user.displayName}. Google authorization bound to tactical systems successfully.`,
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        }
      ]);
      setIsAuthModalOpen(false);
    } catch (err: any) {
      setAuthError(err.message || "Google Authentication failed.");
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authEmail || !authPass) return;
    try {
      setAuthError(null);
      setIsLoading(true);
      if (isAuthModeSignup) {
        await signUpWithEmail(authEmail, authPass);
      } else {
        await signInWithEmail(authEmail, authPass);
      }
      setIsAuthModalOpen(false);
      setAuthEmail("");
      setAuthPass("");
    } catch (err: any) {
      setAuthError(err.message || "Authentication failed.");
    } finally {
      setIsLoading(false);
    }
  };

  // Sync theme to localStorage
  useEffect(() => {
    localStorage.setItem("crni_agent_theme", theme);
  }, [theme]);

  const activeTheme = themeConfig[theme];

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      sender: "crni",
      text: "I am ready and fully synchronized, Sir. CRNI core engine is active 100%. Let me know what routes, regions, or tactical calculations you'd like me to perform today.",
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    },
  ]);
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speechEnabled, setSpeechEnabled] = useState(true);
  const [voicePreset, setVoicePreset] = useState<"FRIDAY_SOOTHING" | "CRNI_SOOTHING_M" | "CRNI_CYBER_03">("FRIDAY_SOOTHING");
  const [mobileActiveTab, setMobileActiveTab] = useState<"assistant" | "map">("assistant");

  const [savedLocations, setSavedLocations] = useState<SavedLocation[]>(() => {
    const saved = localStorage.getItem("crni_agent_saved_locations");
    return saved ? JSON.parse(saved) : [];
  });

  // Sync saved locations to localStorage
  useEffect(() => {
    localStorage.setItem("crni_agent_saved_locations", JSON.stringify(savedLocations));
  }, [savedLocations]);

  const saveCurrentLocation = (name?: string) => {
    const locName = name || `Location ${savedLocations.length + 1}`;
    const newLoc: SavedLocation = {
      id: Math.random().toString(36).substr(2, 9),
      name: locName,
      coords: [mapCenter[0], mapCenter[1]],
      timestamp: Date.now(),
    };
    setSavedLocations((prev) => [newLoc, ...prev]);
  };

  const deleteSavedLocation = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSavedLocations((prev) => prev.filter((loc) => loc.id !== id));
  };

  // Dynamic Telemetry states linked to Leaflet map interaction
  const [mapCenter, setMapCenter] = useState<[number, number]>([50.0, 10.0]); // Initialized to Europe
  const [mapZoom, setMapZoom] = useState<number>(4); // Increased zoom for regional focus
  const [mapStatus, setMapStatus] = useState<string>("SYSTEM: ACTIVE");
  
  // Weather Intelligence States
  const [weatherData, setWeatherData] = useState<{
    temp: number;
    description: string;
    icon: React.ReactNode;
    lastUpdated: string;
  } | null>(null);
  const [isWeatherLoading, setIsWeatherLoading] = useState(false);

  // Fetch weather data for the current map center (debounced)
  useEffect(() => {
    const fetchWeather = async () => {
      setIsWeatherLoading(true);
      try {
        const [lat, lon] = mapCenter;
        const response = await fetch(
          `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&timezone=auto`
        );
        const data = await response.json();
        
        if (data && data.current_weather) {
          const cw = data.current_weather;
          
          const getCondition = (code: number) => {
            if (code <= 3) return { text: "CLEAR SKIES", icon: <Sun className="h-3 w-3 text-yellow-400" /> };
            if (code <= 48) return { text: "FOGGY/OVERCAST", icon: <Cloud className="h-3 w-3 text-zinc-400" /> };
            if (code <= 67) return { text: "MODERATE RAIN", icon: <CloudRain className="h-3 w-3 text-cyan-400" /> };
            if (code <= 77) return { text: "SNOWFALL", icon: <CloudLightning className="h-3 w-3 text-blue-200" /> };
            if (code <= 99) return { text: "THUNDERSTORM", icon: <CloudLightning className="h-3 w-3 text-purple-500" /> };
            return { text: "UNKNOWN ATM", icon: <Cloud className="h-3 w-3 text-zinc-500" /> };
          };

          const condition = getCondition(cw.weathercode);
          setWeatherData({
            temp: cw.temperature,
            description: condition.text,
            icon: condition.icon,
            lastUpdated: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          });
        }
      } catch (err) {
        console.error("Atmospheric scan failed:", err);
      } finally {
        setIsWeatherLoading(false);
      }
    };

    const timer = setTimeout(fetchWeather, 800);
    return () => clearTimeout(timer);
  }, [mapCenter]);

  const [routingState, setRoutingState] = useState<RoutingState>({
    from: null,
    to: null,
    distanceKm: null,
  });

  const [customSearchOrigin, setCustomSearchOrigin] = useState("");
  const [customSearchDest, setCustomSearchDest] = useState("");

  // New GIS features state
  const [mapTileStyle, setMapTileStyle] = useState<"dark" | "satellite" | "minimal">("dark");
  const [distanceUnit, setDistanceUnit] = useState<"KM" | "MI" | "NM">("KM");
  const [selectedClickCoords, setSelectedClickCoords] = useState<[number, number] | null>(null);
  const [isHudCollapsed, setIsHudCollapsed] = useState(true);

  // Subscribe to Authentication state on boot
  useEffect(() => {
    const unsubscribe = subscribeToAuth(async (user) => {
      setCurrentUser(user);
      if (user) {
        try {
          const prefs = await getUserPreferences(user.uid);
          if (prefs?.currency) {
            setPreferredCurrency(prefs.currency);
            localStorage.setItem("crni_agent_currency", prefs.currency);
          }
        } catch (err) {
          console.warn("Master, preference synchronization failed. Using local presets.", err);
        }
      }
    });
    return () => unsubscribe();
  }, []);

  const handleCurrencyChange = async (currency: string) => {
    setPreferredCurrency(currency);
    localStorage.setItem("crni_agent_currency", currency);
    if (currentUser) {
      try {
        await saveUserPreferences(currentUser.uid, { currency });
      } catch (err) {
        console.warn("Master, failed to persist currency preference to cloud storage.", err);
      }
    }
  };


  // Refs
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markersRef = useRef<L.Marker[]>([]);
  const polylineRef = useRef<L.Polyline | null>(null);
  const chatBottomRef = useRef<HTMLDivElement | null>(null);
  const recognitionRef = useRef<any>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);
  const clickMarkerRef = useRef<L.Marker | null>(null);
  const handleMapClickRef = useRef<(lat: number, lng: number) => void>(() => {});
  const handleSubmitRef = useRef<any>(null);

  // Keep submission ref updated on every state sync to prevent closures
  useEffect(() => {
    handleSubmitRef.current = handleSubmit;
  });

  // Initialize Leaflet Map with telemetry event binders
  useEffect(() => {
    if (mapContainerRef.current && !mapRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [20, 0],
        zoom: 2,
        zoomControl: false,
        attributionControl: false,
        zoomAnimation: true,
        fadeAnimation: true,
        markerZoomAnimation: true,
      });

      // CARTO DB Dark tiles matching original slate style
      const initialTile = L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
        maxZoom: 19,
      }).addTo(map);
      tileLayerRef.current = initialTile;

      // Attribution layout adjustment
      L.control
        .attribution({
          position: "bottomright",
          prefix: false,
        })
        .addAttribution("&copy; OpenStreetMap &copy; CARTO")
        .addTo(map);

      // Top Right Zoom HUD
      L.control.zoom({ position: "topright" }).addTo(map);

      // Click callback
      map.on("click", (e: L.LeafletMouseEvent) => {
        handleMapClickRef.current(e.latlng.lat, e.latlng.lng);
      });

      // Telemetry synchronizers
      map.on("move", () => {
        const center = map.getCenter();
        setMapCenter([center.lat, center.lng]);
      });

      map.on("zoomend", () => {
        setMapZoom(map.getZoom());
      });

      mapRef.current = map;

      // Ensure Leaflet recalculates tiles when container dimensions change
      const resizeObserver = new ResizeObserver(() => {
        if (mapRef.current) {
          mapRef.current.invalidateSize();
        }
      });
      if (mapContainerRef.current) {
        resizeObserver.observe(mapContainerRef.current);
      }

      // Initial validation timer
      const resizeTimer = setTimeout(() => {
        if (mapRef.current) {
          mapRef.current.invalidateSize();
        }
      }, 250);

      (map as any)._resizeObserver = resizeObserver;
      (map as any)._resizeTimer = resizeTimer;
    }

    return () => {
      if (mapRef.current) {
        const customMap = mapRef.current as any;
        if (customMap._resizeObserver) {
          customMap._resizeObserver.disconnect();
        }
        if (customMap._resizeTimer) {
          clearTimeout(customMap._resizeTimer);
        }
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, []);

  // Synchronize dynamic map clicks reference
  useEffect(() => {
    handleMapClickRef.current = (lat: number, lng: number) => {
      setSelectedClickCoords([lat, lng]);

      if (clickMarkerRef.current) {
        clickMarkerRef.current.remove();
      }

      const map = mapRef.current;
      if (map) {
        const createClickMarkerIcon = () => {
          return L.divIcon({
            className: "custom-click-glow animate-pulse",
            html: `
              <div class="relative flex flex-col items-center">
                <div style="
                  width: 14px;
                  height: 14px;
                  border: 2px solid #ec4899;
                  border-radius: 50%;
                  background-color: rgba(236,72,153,0.35);
                  box-shadow: 0 0 10px #ec4899, 0 0 20px #ec4899;
                "></div>
              </div>
            `,
            iconSize: [24, 24],
            iconAnchor: [12, 12],
          });
        };

        const clickMarker = L.marker([lat, lng], {
          icon: createClickMarkerIcon(),
        }).addTo(map);
        clickMarkerRef.current = clickMarker;
      }
    };
  });

  // Listen and swap map styles
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (tileLayerRef.current) {
      tileLayerRef.current.remove();
    }

    let url = "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png";
    if (mapTileStyle === "satellite") {
      url = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}";
    } else if (mapTileStyle === "minimal") {
      url = "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png";
    }

    const newTiles = L.tileLayer(url, {
      maxZoom: 19,
    }).addTo(map);

    tileLayerRef.current = newTiles;
  }, [mapTileStyle]);

  // Scroll logic
  useEffect(() => {
    const timer = setTimeout(() => {
      chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 100);
    return () => clearTimeout(timer);
  }, [messages, isLoading]);

  // Synthesis Voice Synthesizer
  const speakText = (text: string) => {
    if (!speechEnabled) return;
    if (typeof window === "undefined" || !window.speechSynthesis) return;

    window.speechSynthesis.cancel();
    const cleanText = text.replace(/[*#`_\[\]()]+/g, " ");
    const utterance = new SpeechSynthesisUtterance(cleanText);
    const voices = window.speechSynthesis.getVoices();

    let voice = voices.find((v) => v.lang.startsWith("en"));

    if (voicePreset === "CRNI_SOOTHING_M") {
      voice =
        voices.find(
          (v) =>
            v.lang.startsWith("en") &&
            (v.name.toLowerCase().includes("male") ||
              v.name.toLowerCase().includes("david") ||
              v.name.toLowerCase().includes("mark"))
        ) || voice;
      utterance.pitch = 0.78; // Deep, warming, comforting tone
      utterance.rate = 0.84;  // Unhurried speech cadence
    } else if (voicePreset === "CRNI_CYBER_03") {
      voice = voices.find((v) => v.lang.startsWith("en")) || voice;
      utterance.pitch = 0.45; // Soft ambient retro mechanoid soundscape 
      utterance.rate = 0.88;
    } else {
      // FRIDAY_SOOTHING - Cozy, soothing Friday bot
      const preferredVendors = ["en-ie", "en-gb", "en-us"];
      for (const lang of preferredVendors) {
        const matched = voices.find(
          (v) =>
            v.lang.toLowerCase().replace("_", "-").startsWith(lang) &&
            (v.name.toLowerCase().includes("female") ||
              v.name.toLowerCase().includes("ireland") ||
              v.name.toLowerCase().includes("irish") ||
              v.name.toLowerCase().includes("samantha") ||
              v.name.toLowerCase().includes("natural us") ||
              v.name.toLowerCase().includes("hazel") ||
              v.name.toLowerCase().includes("zira"))
        );
        if (matched) {
          voice = matched;
          break;
        }
      }
      utterance.pitch = 1.0;
      utterance.rate = 0.82;
    }

    if (voice) utterance.voice = voice;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  // Refined Speech Recognition for Mobile and Desktop
  const toggleListening = async () => {
    if (isListening) {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {
          console.error("Error stopping capture:", e);
        }
      }
      setIsListening(false);
      return;
    }

    setIsSpeaking(false);
    window.speechSynthesis.cancel();

    const SpeechRecognitionAPI =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognitionAPI) {
      setMessages((prev) => [
        ...prev,
        {
          id: Math.random().toString(),
          sender: "crni",
          text: "🎤 Speech recognition is not supported in this browser layout. Please use the terminal input directly or open in a new tab for native hardware access.",
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
      return;
    }

    // Initialize or refresh the recognition instance
    if (!recognitionRef.current) {
      const recognition = new SpeechRecognitionAPI();
      recognition.continuous = false;
      recognition.interimResults = true; // Enable live transcription
      recognition.lang = "en-US";

      recognition.onstart = () => {
        setIsListening(true);
        // Haptic feedback for mobile if supported
        if (typeof navigator !== "undefined" && navigator.vibrate) {
          navigator.vibrate(20);
        }
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.onerror = (e: any) => {
        console.error("Mic Core Error:", e.error);
        setIsListening(false);
        
        let errorMsg = "🎤 Terminal capture failed. Please try again.";
        if (e.error === "not-allowed") {
          errorMsg = "🎤 Permission denied. Please grant microphone access in browser settings or open this app in its own tab.";
        } else if (e.error === "no-speech") {
          return; // Silent fail for no speech detected
        }

        setMessages((prev) => [
          ...prev,
          {
            id: Math.random().toString(),
            sender: "crni",
            text: errorMsg,
            timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          },
        ]);
      };

      recognition.onresult = (event: any) => {
        let finalTranscript = "";
        let interimTranscript = "";

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }

        if (interimTranscript) {
          setInputText(interimTranscript);
        }

        if (finalTranscript) {
          const cleanTranscript = finalTranscript.trim();
          if (cleanTranscript) {
            setInputText(cleanTranscript);
            // Wait a brief moment to show the user their text before sending
            setTimeout(() => {
              if (handleSubmitRef.current) {
                handleSubmitRef.current(null, cleanTranscript);
              }
            }, 500);
          }
        }
      };

      recognitionRef.current = recognition;
    }

    try {
      recognitionRef.current.start();
    } catch (err) {
      console.warn("Restarting speech engine...", err);
      // Sometimes instances get stuck in a "starting" state on mobile
      try {
        recognitionRef.current.stop();
        setTimeout(() => recognitionRef.current.start(), 250);
      } catch (inner) {
        console.error("Fatal mic boot failure:", inner);
      }
    }
  };

  // High tech custom glowing marker
  const createGlowMarker = (color: string, label: string) => {
    return L.divIcon({
      className: "custom-glow",
      html: `
        <div class="relative flex flex-col items-center">
          <div style="
            width: 12px;
            height: 12px;
            background-color: ${color};
            border: 2px solid #ffffff;
            border-radius: 50%;
            box-shadow: 0 0 12px ${color}, 0 0 24px ${color};
          "></div>
          <div class="absolute top-4 bg-zinc-950/95 font-mono text-[9px] tracking-widest px-2 py-0.5 rounded border border-zinc-800 whitespace-nowrap shadow-xl" style="color: var(--theme-accent);">
            ${label.toUpperCase()}
          </div>
        </div>
      `,
      iconSize: [16, 40],
      iconAnchor: [8, 8],
    });
  };

  const geocodePlace = async (placeName: string): Promise<[number, number] | null> => {
    try {
      const resp = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(placeName)}&limit=1`,
        {
          headers: {
            "Accept": "application/json",
            "User-Agent": "CrniGeomBalance/2.0",
          },
        }
      );
      if (!resp.ok) return null;
      const data = await resp.json();
      if (data && data.length > 0) {
        return [parseFloat(data[0].lat), parseFloat(data[0].lon)];
      }
    } catch (err) {
      console.error("Geocoding service delay:", err);
    }
    return null;
  };

  const calculateHaversine = (coords1: [number, number], coords2: [number, number]): number => {
    const R = 6371; // Earth radius in KM
    const dLat = ((coords2[0] - coords1[0]) * Math.PI) / 180;
    const dLon = ((coords2[1] - coords1[1]) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((coords1[0] * Math.PI) / 180) *
        Math.cos((coords2[0] * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  // Perform GIS actions on leaflet map
  const applyMapAction = async (mapAction: any) => {
    const map = mapRef.current;
    if (!map) return;

    markersRef.current.forEach((m) => m.remove());
    markersRef.current = [];
    if (polylineRef.current) {
      polylineRef.current.remove();
      polylineRef.current = null;
    }

    if (!mapAction || mapAction.type === "none") {
      setMapStatus("SYSTEM: STABLE");
      return;
    }

    setMapStatus(`PLOT: ${mapAction.toName.toUpperCase()}`);

    if (mapAction.type === "show_location" && mapAction.toName) {
      const coords = await geocodePlace(mapAction.toName);
      if (coords) {
        const marker = L.marker(coords, {
          icon: createGlowMarker("#06b6d4", mapAction.toName),
        }).addTo(map);

        markersRef.current.push(marker);
        map.flyTo(coords, 10, { duration: 2.0 });
        setMapStatus(`FOCUS TRACE: ${mapAction.toName.toUpperCase()}`);
        setRoutingState({
          from: null,
          to: { name: mapAction.toName, coords },
          distanceKm: null,
        });
      } else {
        setMapStatus("PLOT FAIL: GEOCODE ERROR");
      }
    } else if (mapAction.type === "calculate_route" && mapAction.fromName && mapAction.toName) {
      setMapStatus(`ROUTE: ${mapAction.fromName.toUpperCase()} TO ${mapAction.toName.toUpperCase()}`);
      const fromCoords = await geocodePlace(mapAction.fromName);
      const toCoords = await geocodePlace(mapAction.toName);

      if (fromCoords && toCoords) {
        const mFrom = L.marker(fromCoords, {
          icon: createGlowMarker("#a855f7", `A: ${mapAction.fromName}`),
        }).addTo(map);

        const mTo = L.marker(toCoords, {
          icon: createGlowMarker("#ec4899", `B: ${mapAction.toName}`),
        }).addTo(map);

        markersRef.current.push(mFrom, mTo);

        // Fetch precise road route
        let routePoints: [number, number][] = [fromCoords, toCoords];
        let distanceKm = calculateHaversine(fromCoords, toCoords);
        let roadStatus = "GEODESIC PATH";

        try {
          const res = await fetch("/api/route", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ 
              origin: { lat: fromCoords[0], lng: fromCoords[1] },
              destination: { lat: toCoords[0], lng: toCoords[1] },
              travelMode: "DRIVE"
            })
          });
          
          if (res.ok) {
            const data = await res.json();
            if (data.routes && data.routes[0]) {
              const route = data.routes[0];
              if (route.polyline && route.polyline.encodedPolyline) {
                const decoded = polyline.decode(route.polyline.encodedPolyline);
                if (decoded && decoded.length > 0) {
                  routePoints = decoded as [number, number][];
                  distanceKm = (route.distanceMeters || 0) / 1000;
                  roadStatus = "TACTICAL ROAD ROUTE";
                }
              }
            }
          }
        } catch (routeErr) {
          console.error("Precise routing failed:", routeErr);
        }

        const routeLine = L.polyline(routePoints, {
          color: roadStatus === "TACTICAL ROAD ROUTE" ? "#10b981" : "#06b6d4",
          weight: 4,
          dashArray: roadStatus === "TACTICAL ROAD ROUTE" ? "" : "6, 8",
          opacity: 0.95,
        }).addTo(map);

        polylineRef.current = routeLine;

        map.fitBounds(routeLine.getBounds(), {
          padding: [50, 50],
        });

        setRoutingState({
          from: { name: mapAction.fromName, coords: fromCoords },
          to: { name: mapAction.toName, coords: toCoords },
          distanceKm: parseFloat(distanceKm.toFixed(2)),
        });

        setMapStatus(`${roadStatus}: ${distanceKm.toFixed(1)} KM`);
      } else {
        setMapStatus("PLOT FAIL: TRANSIT ERROR");
      }
    }
  };

  // Submit trigger to API routes
  const handleSubmit = async (e: React.FormEvent | null, forcedText?: string) => {
    if (e) e.preventDefault();
    const message = (forcedText || inputText).trim();
    if (!message) return;

    setInputText("");
    const userMsgId = Math.random().toString();
    const newMsg: ChatMessage = {
      id: userMsgId,
      sender: "user",
      text: message,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, newMsg]);
    setIsLoading(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message,
          currency: preferredCurrency,
          history: messages.slice(-8).map((msg) => ({
            role: msg.sender === "user" ? "user" : "model",
            text: msg.text,
          })),
        }),
      });

      let resData: CrniResponse;
      try {
        resData = await response.json();
      } catch (parseErr) {
        if (!response.ok) {
          throw new Error("API Connection Timeout");
        }
        throw new Error("Invalid response format");
      }

      if (!response.ok) {
        if (resData && resData.reply) {
          const crniMsgId = Math.random().toString();
          const crniMsg: ChatMessage = {
            id: crniMsgId,
            sender: "crni",
            text: resData.reply,
            timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
            mapAction: resData.mapAction || { type: "none", fromName: "", toName: "" },
            isLiveTyping: true,
          };
          setMessages((prev) => [...prev, crniMsg]);
          setIsTyping(true);
          speakText(resData.reply);
          return;
        }
        throw new Error((resData as any).error || `Server status ${response.status}`);
      }

      const crniMsgId = Math.random().toString();
      const crniMsg: ChatMessage = {
        id: crniMsgId,
        sender: "crni",
        text: resData.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        mapAction: resData.mapAction,
        travelIntel: resData.travelIntel,
        isLiveTyping: true,
      };

      setMessages((prev) => [...prev, crniMsg]);
      setIsTyping(true);
      setMapStatus("SYSTEM: STREAMING RESPONSE...");

      // Talk TTS speech feedback
      speakText(resData.reply);

      if (resData.mapAction) {
        applyMapAction(resData.mapAction);
      }

    } catch (err: any) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          id: Math.random().toString(),
          sender: "crni",
          text: `Core neural synapse error: ${err.message}. Master, please inspect your environment configuration credentials for a correct state config.`,
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleManualRoute = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customSearchDest) return;

    if (customSearchOrigin) {
      const prompt = `Hey Crni, calculate the distance from ${customSearchOrigin} to ${customSearchDest}.`;
      setInputText(prompt);
      handleSubmit(null, prompt);
    } else {
      const prompt = `Hey Crni, pinpoint ${customSearchDest} on the world map.`;
      setInputText(prompt);
      handleSubmit(null, prompt);
    }

    setCustomSearchOrigin("");
    setCustomSearchDest("");
  };

  // Coordinates formatting helpers
  const formatCoord = (val: number, labelPlus: string, labelMinus: string) => {
    const direct = val >= 0 ? labelPlus : labelMinus;
    return `${Math.abs(val).toFixed(4)}° ${direct}`;
  };

  return (
    <div className={`h-screen bg-zinc-950 text-zinc-300 antialiased flex flex-col font-sans overflow-hidden theme-${theme}`}>
      
      {/* GEOMETRIC BALANCE ACTIVE HEADER PANEL */}
      <header className="h-16 border-b border-zinc-800 flex items-center justify-between px-6 bg-zinc-900/50 z-10 shrink-0">
        <div className="flex items-center gap-4 relative">
          
          {/* THREE DOTS SYSTEM CUSTOMIZER TRIGGER */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsCustomizeOpen(!isCustomizeOpen)}
              className="p-1 px-1.5 rounded border border-zinc-800 hover:border-zinc-700 bg-zinc-950 text-zinc-400 hover:text-white transition-all cursor-pointer flex items-center justify-center font-bold"
              title="Interface Customizer Settings"
            >
              <MoreHorizontal className="h-4 w-4" />
            </button>
          </div>

          {/* Theme Customizer Panel */}
          {isCustomizeOpen && (
            <div className="absolute top-10 left-0 w-72 bg-zinc-950/98 border border-zinc-800 p-4 rounded-md shadow-2xl z-50 font-mono text-[9px] md:text-[10px] tracking-wider text-zinc-450 flex flex-col space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-zinc-900/80 text-zinc-300 font-bold">
                <div className="flex items-center gap-2 uppercase tracking-[0.16em] px-2 py-1">
                  <Palette className="h-3.5 w-3.5 mr-1.5" />
                  SYSTEM CONFIG
                </div>
                <button
                  onClick={() => setIsCustomizeOpen(false)}
                  className="p-0.5 rounded border border-transparent hover:border-zinc-850 text-zinc-500 hover:text-zinc-300 cursor-pointer"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>

              <div className="space-y-3">
                <div className="space-y-1.5">
                  <p className="text-[8px] text-zinc-500 uppercase">// SELECT THEME PALETTE:</p>
                  <div className="flex flex-col gap-1">
                    <select 
                      value={theme}
                      onChange={(e) => setTheme(e.target.value as any)}
                      className="w-full bg-zinc-900 border border-zinc-800 p-2 rounded text-[10px] text-zinc-300 outline-none focus:border-cyan-500 transition-all cursor-pointer font-mono"
                    >
                      <option value="cyan">CYBER SLATE (DEFAULT)</option>
                      <option value="vampire">VAMPIRE BLOOD</option>
                      <option value="forest">FOREST GREEN</option>
                      <option value="chill">CHILL VIBE</option>
                      <option value="kitty">KITTY VIBE</option>
                    </select>

                    {/* Currency Selector */}
                    <div className="mt-4 pt-4 border-t border-zinc-900/80 space-y-2">
                      <p className="text-[8px] text-zinc-500 uppercase">// PREFERRED CURRENCY:</p>
                      <select 
                        value={preferredCurrency}
                        onChange={(e) => handleCurrencyChange(e.target.value)}
                        className="w-full bg-zinc-900 border border-zinc-800 p-2 rounded text-[10px] text-zinc-300 outline-none focus:border-cyan-500 transition-all cursor-pointer font-mono"
                      >
                        <option value="USD">USD ($)</option>
                        <option value="EUR">EUR (€)</option>
                        <option value="GBP">GBP (£)</option>
                        <option value="INR">INR (₹)</option>
                        <option value="JPY">JPY (¥)</option>
                        <option value="AUD">AUD (A$)</option>
                        <option value="CAD">CAD (C$)</option>
                        <option value="AED">AED (د.إ)</option>
                        <option value="CNY">CNY (¥)</option>
                        <option value="BRL">BRL (R$)</option>
                      </select>
                      <p className="text-[7px] text-zinc-600 italic leading-tight">
                        * ALL TACTICAL COSTS WILL BE PROJECTED IN THIS CURRENCY.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="relative group">
            <div className={`absolute -inset-1 ${isLoading || isTyping ? activeTheme.accentBg : "bg-transparent"} rounded-full opacity-0 ${isLoading || isTyping ? "opacity-20 animate-neural" : ""} blur-md transition-all duration-700`} />
            <div className={`w-2.5 h-2.5 ${isLoading || isTyping ? activeTheme.accentBg + " shadow-[0_0_12px_currentColor]" : activeTheme.pulseDot} rounded-full animate-pulse shrink-0 transition-all duration-500 relative`} />
          </div>
          <span className={`text-[10px] md:text-xs font-bold tracking-[0.25em] uppercase font-display transition-all duration-700 ${isLoading || isTyping ? activeTheme.accentText + " text-glow" : "text-zinc-400"}`}>
            {isLoading || isTyping ? "NEURAL LINK ESTABLISHED // PROCESSING" : "System Active // CRNI-AI V1.0"}
          </span>
        </div>

        {/* Live Telemetry Display */}
        <div className="hidden md:flex items-center gap-12 font-mono text-[10px] tracking-widest text-zinc-500">
          <span className="flex items-center gap-1">
            LAT: <span className="text-zinc-300">{formatCoord(mapCenter[0], "N", "S")}</span>
          </span>
          <span className="flex items-center gap-1">
            LNG: <span className="text-zinc-300">{formatCoord(mapCenter[1], "E", "W")}</span>
          </span>
          <span className={`${isLoading || isTyping ? activeTheme.accentText + " animate-pulse" : activeTheme.accentText} transition-all duration-500`}>
            {isLoading || isTyping ? "SIGNAL: STREAMING" : "SIGNAL: STABLE"}
          </span>
        </div>

        {/* Global Battery / Priority HUD tag */}
        <div className="flex items-center gap-3">
          <div className="hidden xs:flex items-center gap-2">
            <div className="h-1.5 w-12 bg-zinc-800 rounded-full overflow-hidden">
              <div className={`h-full w-4/5 ${activeTheme.accentBgDeep} animate-pulse`} />
            </div>
            <span className="text-[10px] font-mono text-zinc-400">ONLINE 100%</span>
          </div>

          <button
            onClick={() => {
              setSpeechEnabled(!speechEnabled);
              if (speechEnabled) window.speechSynthesis.cancel();
            }}
            className={`p-1.5 rounded border transition-all text-xs font-mono ml-3 ${
              speechEnabled
                ? `bg-zinc-900 border-zinc-800 ${activeTheme.accentText} ${activeTheme.hoverBorder}`
                : "bg-red-950/20 border-red-900/40 text-red-400"
            }`}
            title="Toggle Voices Sound Output"
          >
            {speechEnabled ? <Volume2 className="h-3.5 w-3.5" /> : <VolumeX className="h-3.5 w-3.5" />}
          </button>

          {/* User Sign In controls */}
          {currentUser ? (
            <div className="flex items-center gap-2 pl-2 border-l border-zinc-800">
              {currentUser.photoURL ? (
                <img
                  src={currentUser.photoURL}
                  alt={currentUser.displayName || "Agent"}
                  className={`w-6 h-6 rounded-full border ${activeTheme.accentBorderSubtle} ${activeTheme.tagGlow}`}
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className={`w-6 h-6 rounded-full ${activeTheme.bgMuted} border ${activeTheme.accentBorderSubtle} flex items-center justify-center text-[10px] font-bold ${activeTheme.accentText}`}>
                  {currentUser.displayName ? currentUser.displayName[0] : "A"}
                </div>
              )}
              <div className="hidden lg:flex flex-col text-left">
                <span className="text-[9px] font-mono text-zinc-300 font-bold leading-none">
                  {currentUser.displayName || "Agent"}
                </span>
                <span className="text-[8px] font-mono text-zinc-500 leading-none mt-0.5">
                  {currentUser.providerId === "github.com" ? "GITHUB SECURE" : "GOOGLE SECURE"}
                </span>
              </div>
                  <button
                    onClick={async () => {
                      try {
                        await logOut();
                        setMessages([
                          {
                            id: "welcome",
                            sender: "crni",
                            text: "I am ready and fully synchronized, Sir. CRNI core engine is active 100%. Let me know what routes, regions, or tactical calculations you'd like me to perform today.",
                            timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
                          },
                          {
                            id: Math.random().toString(),
                            sender: "crni",
                            text: "Security clearance revoked, Sir. You have been safely logged out. CRNI core continues standing by.",
                            timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
                          }
                        ]);
                      } catch (e: any) {
                        setAuthError(e.message);
                      }
                    }}
                    className="p-1 px-1.5 rounded border border-red-900/40 bg-red-950/20 hover:border-red-500 hover:bg-red-950/40 text-red-400 hover:text-red-300 text-[9px] font-mono transition-all ml-1"
                    title="Log Out Security Key"
                  >
                    <LogOut className="h-3 w-3" />
                  </button>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 pl-2 border-l border-zinc-800">
              <button
                type="button"
                onClick={() => setIsAuthModalOpen(true)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-zinc-900 transition-all font-bold text-xs cursor-pointer shadow-lg shadow-cyan-500/10 ${activeTheme.accentBg}`}
              >
                <LogIn className="h-4 w-4" />
                <span>SIGN IN</span>
              </button>
            </div>
          )}
        </div>
    </header>

      {/* Auth Modal Overlay */}
      {isAuthModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-md bg-zinc-950 border border-zinc-800 rounded-lg overflow-hidden shadow-2xl font-mono"
          >
            <div className={`p-4 border-b border-zinc-900 flex items-center justify-between ${activeTheme.accentBg}`}>
              <h2 className="text-zinc-900 font-bold tracking-[0.2em] flex items-center gap-2">
                <LogIn className="h-4 w-4" />
                CENTRAL AUTHORIZATION
              </h2>
              <button 
                onClick={() => setIsAuthModalOpen(false)}
                className="text-zinc-900/60 hover:text-zinc-900 p-1 transition-all cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              {/* Google Auth Option */}
              <div className="space-y-3">
                <p className="text-[10px] text-zinc-500 uppercase tracking-widest text-center">// OAUTH PROTOCOL</p>
                <button
                  onClick={handleGoogleSignIn}
                  className="w-full flex items-center justify-center gap-3 py-3 bg-zinc-900 border border-zinc-800 rounded-md hover:bg-zinc-800 hover:border-zinc-700 transition-all group cursor-pointer"
                >
                  <div className="bg-white p-1 rounded-full group-hover:scale-110 transition-transform">
                    <svg className="w-4 h-4" viewBox="0 0 24 24">
                      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.65l-3.57-2.77c-.99.66-2.26 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                      <path fill="#FBBC05" d="M5.84 14.11c-.22-.66-.35-1.36-.35-2.11s.13-1.45.35-2.11V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.83z" />
                      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.83c.87-2.6 3.3-4.53 6.16-4.53z" />
                    </svg>
                  </div>
                  <span className="text-zinc-200 font-bold tracking-widest text-xs uppercase">Continue with Google</span>
                </button>
              </div>

              <div className="relative flex items-center justify-center">
                <div className="absolute inset-0 flex items-center px-4">
                  <div className="w-full border-t border-zinc-800"></div>
                </div>
                <span className="relative bg-zinc-950 px-3 text-[9px] text-zinc-600 uppercase tracking-[0.3em]">OR MANUAL OVERRIDE</span>
              </div>

              {/* Email/Password Option */}
              <form onSubmit={handleEmailAuth} className="space-y-4">
                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <label className="text-[10px] text-zinc-500 uppercase tracking-widest">TACTICAL EMAIL</label>
                    <input 
                      type="email"
                      required
                      value={authEmail}
                      onChange={(e) => setAuthEmail(e.target.value)}
                      placeholder="agent@matrix.net"
                      className="w-full bg-zinc-900/50 border border-zinc-850 p-2.5 rounded text-xs text-zinc-100 placeholder:text-zinc-700 focus:outline-none focus:border-cyan-500/50 transition-all font-mono"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] text-zinc-500 uppercase tracking-widest">ENCRYPTION KEY</label>
                    <input 
                      type="password"
                      required
                      value={authPass}
                      onChange={(e) => setAuthPass(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-zinc-900/50 border border-zinc-850 p-2.5 rounded text-xs text-zinc-100 placeholder:text-zinc-700 focus:outline-none focus:border-cyan-500/50 transition-all font-mono"
                    />
                  </div>
                  
                  {/* Currency Selection during sign-in */}
                  <div className="space-y-1.5 pt-2">
                    <label className="text-[10px] text-zinc-500 uppercase tracking-widest">TACTICAL CURRENCY</label>
                    <select 
                      value={preferredCurrency}
                      onChange={(e) => handleCurrencyChange(e.target.value)}
                      className="w-full bg-zinc-900/50 border border-zinc-850 p-2.5 rounded text-xs text-zinc-100 transition-all font-mono outline-none focus:border-cyan-500/50 cursor-pointer"
                    >
                      <option value="USD">USD ($)</option>
                      <option value="EUR">EUR (€)</option>
                      <option value="GBP">GBP (£)</option>
                      <option value="INR">INR (₹)</option>
                      <option value="JPY">JPY (¥)</option>
                      <option value="AUD">AUD (A$)</option>
                      <option value="CAD">CAD (C$)</option>
                      <option value="AED">AED (د.إ)</option>
                      <option value="CNY">CNY (¥)</option>
                      <option value="BRL">BRL (R$)</option>
                    </select>
                  </div>
                </div>

                {authError && (
                  <div className="p-2 bg-red-950/20 border border-red-900/50 rounded text-red-500 text-[10px] leading-tight uppercase font-bold text-center">
                    ERROR: {authError}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isLoading}
                  className={`w-full py-3 rounded font-bold text-xs uppercase tracking-widest transition-all cursor-pointer ${activeTheme.accentBg} text-zinc-900 hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50`}
                >
                  {isLoading ? "PROCESSING..." : isAuthModeSignup ? "REGISTER AGENT" : "AUTHORIZE ACCESS"}
                </button>

                <p className="text-[10px] text-zinc-500 text-center">
                  {isAuthModeSignup ? "Already registered?" : "New Agent?"}{" "}
                  <button 
                    type="button" 
                    onClick={() => setIsAuthModeSignup(!isAuthModeSignup)}
                    className={`${activeTheme.accentText} font-bold hover:underline cursor-pointer`}
                  >
                    {isAuthModeSignup ? "SWAP TO LOGIN" : "INITIALIZE REGISTRATION"}
                  </button>
                </p>
              </form>
            </div>
            
            <div className="p-4 bg-zinc-900/30 border-t border-zinc-900 text-[9px] text-zinc-600 italic text-center">
              SECURE CHAT PERSISTENCE REQUIRES ACTIVE AUTHORIZATION PROFILE.
            </div>
          </motion.div>
        </div>
      )}

      {/* MAIN CONTAINER LAYOUT */}
      <main className="flex-1 flex flex-col overflow-hidden relative bg-zinc-950">
        
        {/* MAP PORTION: takes up exactly 60% of the screen space */}
        <div className="h-[60%] w-full relative border-b border-zinc-900 bg-zinc-950 overflow-hidden shrink-0">
          {/* LEAFLET GEOGRAPHIC CONTAINER: bounded in the 60% height container */}
          <div className="absolute inset-0 z-0 w-full h-full" ref={mapContainerRef} />

          {/* Ambient matrix micro dot pattern overlay */}
          <div className="absolute inset-0 opacity-15 pointer-events-none bg-grid-dots bg-repeat z-[2]" />

          {/* FLOATING HUD INTERACTIVE LAYER (inside the 60% map viewport) */}
          <div className="absolute inset-0 z-[5] pointer-events-none flex flex-col justify-between p-3 md:p-6 overflow-hidden">
          
          {/* Inside floating navigation monitor overlay */}
          <div className="absolute top-3 left-3 md:top-4 md:left-4 z-[10] max-w-[calc(100vw-24px)] sm:max-w-xs md:max-w-sm bg-zinc-950/95 backdrop-blur-md p-3 rounded border border-zinc-800 shadow-2xl flex flex-col font-mono text-[9px] md:text-[10px] tracking-wider text-zinc-400 pointer-events-auto transition-all duration-300">
            <div 
              onClick={() => setIsHudCollapsed(!isHudCollapsed)}
              className={`flex items-center justify-between ${activeTheme.accentText} font-bold cursor-pointer ${activeTheme.hoverTextMuted} select-none pb-0.5`}
            >
              <div className="flex items-center space-x-2">
                <Compass className={`h-3.5 w-3.5 ${activeTheme.accentText} animate-spin`} style={{ animationDuration: "14s" }} />
                <span className="uppercase tracking-[0.16em]">GEODESIC GPS HUD</span>
              </div>
              <span className={`text-[8px] bg-zinc-900 px-1.5 py-0.5 rounded text-zinc-400 border border-zinc-800 uppercase tracking-widest ${activeTheme.hoverBorder} ${activeTheme.hoverText} transition-all font-bold`}>
                {isHudCollapsed ? "Expand" : "Collapse"}
              </span>
            </div>
            
            {!isHudCollapsed && (
              <div className="flex flex-col space-y-1.5 pt-2 border-t border-zinc-900/80 animate-fade-in">
                <div className="flex items-center justify-between">
                  <span>TELEMETRY:</span>
                  <span className="text-zinc-200 font-bold">{mapStatus}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span>RESOLUTION:</span>
                  <span className="text-zinc-200">{mapZoom} ZOOM LEVEL</span>
                </div>

                {/* WEATHER WIDGET: Atmospheric Intelligence */}
                <div className="flex flex-col border-t border-zinc-850 pt-1.5 mt-0.5 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-zinc-500">ATMOSPHERIC:</span>
                    {isWeatherLoading ? (
                      <RefreshCw className="h-2.5 w-2.5 animate-spin text-zinc-600" />
                    ) : (
                      <span className="text-[7px] text-zinc-600 font-mono">UPDATED {weatherData?.lastUpdated}</span>
                    )}
                  </div>
                  
                  {weatherData ? (
                    <div className="flex items-center justify-between bg-zinc-900/40 p-1.5 rounded border border-zinc-850/50">
                      <div className="flex items-center gap-2">
                        <div className="bg-zinc-950 p-1 rounded border border-zinc-900">
                          {weatherData.icon}
                        </div>
                        <div className="flex flex-col">
                          <span className={`${activeTheme.accentText} font-bold text-[9px] uppercase tracking-tighter`}>{weatherData.description}</span>
                          <span className="text-[7px] text-zinc-600 uppercase">COORDINATE SCAN ACTIVE</span>
                        </div>
                      </div>
                      <div className="flex flex-col items-end">
                        <span className="text-zinc-100 font-bold text-xs tabular-nums">{weatherData.temp}°C</span>
                        <span className="text-[6px] text-zinc-600 uppercase font-mono">CORE_TEMP_SENSE</span>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center py-2 border border-dashed border-zinc-900 rounded">
                      <span className="text-[7px] text-zinc-600 uppercase tracking-widest italic">Scanning Atmosphere...</span>
                    </div>
                  )}
                </div>

                {/* FEATURE 3: Dynamic Map Styles overlay */}
                <div className="flex items-center justify-between border-t border-zinc-850 pt-1.5 mt-0.5">
                  <span className="text-zinc-500">MAP LAYERS:</span>
                  <div className="flex gap-1">
                    {(["dark", "satellite", "minimal"] as const).map((style) => (
                      <button
                        key={style}
                        type="button"
                        onClick={() => setMapTileStyle(style)}
                        className={`text-[8px] font-mono px-1.5 py-0.5 rounded border transition-all uppercase tracking-wide cursor-pointer ${
                          mapTileStyle === style
                            ? `${activeTheme.accentBgMutedHeader} ${activeTheme.accentBorder} ${activeTheme.accentText} font-bold`
                            : "bg-zinc-900 border-zinc-800 text-zinc-500 hover:text-zinc-350"
                        }`}
                      >
                        {style}
                      </button>
                    ))}
                  </div>
                </div>

                {/* FEATURE 2: Saved Locations Panel */}
                <div className="border-t border-zinc-850 pt-1.5 mt-0.5">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-[8px] tracking-[0.15em] text-zinc-500 uppercase">// SAVED LOCATIONS:</p>
                    <button
                      type="button"
                      onClick={() => {
                        const name = prompt("Enter location name:");
                        if (name !== null) saveCurrentLocation(name);
                      }}
                      className={`flex items-center gap-1 text-[7px] font-bold ${activeTheme.accentText} bg-zinc-900 border ${activeTheme.accentBorderMuted} px-1.5 py-0.5 rounded ${activeTheme.hoverBorder} transition-all cursor-pointer`}
                    >
                      <Plus className="h-2 w-2" />
                      SAVE CURRENT
                    </button>
                  </div>
                  
                  <div className="flex flex-col gap-1 max-h-[100px] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-zinc-800">
                    {savedLocations.length === 0 ? (
                      <p className="text-[7px] text-zinc-600 italic">No stored coordinates in core buffer.</p>
                    ) : (
                      savedLocations.map((loc) => (
                        <div
                          key={loc.id}
                          onClick={() => {
                            const map = mapRef.current;
                            if (map) {
                              map.flyTo(loc.coords, 10, { duration: 1.5 });
                              setMapStatus(`RECALL: ${loc.name.toUpperCase()}`);
                            }
                          }}
                          className={`group flex items-center justify-between p-1.5 bg-zinc-900 border border-zinc-850 ${activeTheme.hoverBorderMuted} rounded text-[8px] transition-all cursor-pointer`}
                        >
                          <div className="flex flex-col">
                            <span className="text-zinc-200 font-bold uppercase truncate max-w-[150px]">{loc.name}</span>
                            <span className="text-[7px] text-zinc-500">
                              {loc.coords[0].toFixed(4)}°N, {loc.coords[1].toFixed(4)}°E
                            </span>
                          </div>
                          <button
                            onClick={(e) => deleteSavedLocation(loc.id, e)}
                            className="p-1 opacity-0 group-hover:opacity-100 text-zinc-600 hover:text-red-500 transition-all"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            )}

            {routingState.to && (
              <div className="border-t border-zinc-800 pt-1.5 mt-1 font-mono text-[9px] space-y-1.5">
                {routingState.from ? (
                  <>
                    <div className="flex justify-between">
                      <span>POINT A:</span>
                      <span className="text-purple-400 font-bold max-w-[120px] truncate">{routingState.from.name.toUpperCase()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>POINT B:</span>
                      <span className="text-pink-400 font-bold max-w-[120px] truncate">{routingState.to.name.toUpperCase()}</span>
                    </div>

                    {/* FEATURE 4: Distance Unit conversions */}
                    <div className={`` + activeTheme.accentBgMuted + ` p-2 rounded border ` + activeTheme.accentBorderMuted + ` text-zinc-100 flex flex-col mt-1 gap-1`}>
                      <div className="flex justify-between items-center">
                        <span className={`${activeTheme.accentText} font-bold`}>RANGE DIST:</span>
                        <span className={`${activeTheme.accentTextMuted} font-bold text-xs select-text`}>
                          {distanceUnit === "KM" && `${routingState.distanceKm} KM`}
                          {distanceUnit === "MI" && `${(routingState.distanceKm! * 0.621371).toFixed(1)} MILES`}
                          {distanceUnit === "NM" && `${(routingState.distanceKm! * 0.539957).toFixed(1)} NM`}
                        </span>
                      </div>
                      <div className="flex gap-1 justify-end">
                        {(["KM", "MI", "NM"] as const).map((unit) => (
                          <button
                            key={unit}
                            type="button"
                            onClick={() => setDistanceUnit(unit)}
                            className={`text-[7px] px-1 py-0.5 rounded font-mono font-bold transition-all cursor-pointer ${
                              distanceUnit === unit
                                ? `${activeTheme.accentBg} text-zinc-950 ${activeTheme.accentBgHover}`
                                : "bg-zinc-900 text-zinc-400 hover:text-zinc-300 border border-zinc-800"
                            }`}
                          >
                            {unit}
                          </button>
                        ))}
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="flex justify-between items-center bg-zinc-900 px-1.5 py-1 rounded">
                    <span>TRACE FOCUS:</span>
                    <span className={`${activeTheme.accentText} font-bold truncate max-w-[120px]`}>{routingState.to.name.toUpperCase()}</span>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Spacer to push planner coordinates trigger */}
          <div className="flex-1" />

          {/* FEATURE 1: Interactive Marker Click Targeting overlay popover */}
          {selectedClickCoords && (
            <div className="absolute bottom-16 left-3 right-3 md:bottom-20 md:left-4 md:right-4 z-[500] bg-zinc-950/95 backdrop-blur-md p-3 rounded border border-zinc-800 shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-3 font-mono text-[9px] md:text-[10px] pointer-events-auto">
              <div className="flex items-center space-x-2 text-pink-400">
                <span className="w-2 h-2 rounded-full bg-pink-500 animate-ping shrink-0" />
                <span className="font-semibold uppercase tracking-wider">TARGET IN BOUNDS: {selectedClickCoords[0].toFixed(4)}°, {selectedClickCoords[1].toFixed(4)}°</span>
              </div>
              <div className="flex items-center gap-1.5 w-full sm:w-auto justify-end">
                <button
                  type="button"
                  onClick={() => {
                    setCustomSearchOrigin(`${selectedClickCoords[0].toFixed(4)}, ${selectedClickCoords[1].toFixed(4)}`);
                    setSelectedClickCoords(null);
                    if (clickMarkerRef.current) clickMarkerRef.current.remove();
                  }}
                  className="px-2 py-1.5 bg-zinc-900 hover:bg-zinc-800 hover:text-white border border-zinc-800 text-zinc-400 rounded uppercase transition-all whitespace-nowrap cursor-pointer"
                >
                  Set Origin A
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setCustomSearchDest(`${selectedClickCoords[0].toFixed(4)}, ${selectedClickCoords[1].toFixed(4)}`);
                    setSelectedClickCoords(null);
                    if (clickMarkerRef.current) clickMarkerRef.current.remove();
                  }}
                  className="px-2 py-1.5 bg-zinc-900 hover:bg-zinc-800 hover:text-white border border-zinc-800 text-zinc-400 rounded uppercase transition-all whitespace-nowrap cursor-pointer"
                >
                  Set Dest B
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const latVal = selectedClickCoords[0].toFixed(4);
                    const lngVal = selectedClickCoords[1].toFixed(4);
                    const prompt = `Hey Crni, analyze the location at coordinates latitude ${latVal}, longitude ${lngVal}. Tell me what is there, any interesting trivia, and what country it belongs to.`;
                    setInputText(prompt);
                    handleSubmit(null, prompt);
                    setSelectedClickCoords(null);
                    if (clickMarkerRef.current) clickMarkerRef.current.remove();
                  }}
                  className="px-2.5 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-zinc-950 font-bold rounded uppercase transition-all whitespace-nowrap cursor-pointer"
                >
                  Analyze Point
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedClickCoords(null);
                    if (clickMarkerRef.current) clickMarkerRef.current.remove();
                  }}
                  className="p-1 px-1.5 bg-zinc-900 border border-zinc-805 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded transition-all cursor-pointer"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          )}

        </div>
        </div>

        {/* =========================================================================
            DOWNWARDS COGNITIVE LOG TERMINAL (Transparent/Translucent when location is active or tracking)
            ========================================================================= */}
        <section
          className={`w-full flex-1 border-t flex flex-col overflow-hidden relative z-[10] transition-all duration-[700ms] ease-in-out ${
            routingState.to !== null || selectedClickCoords !== null || (mapStatus && mapStatus !== "SYSTEM: ACTIVE" && mapStatus !== "SYSTEM: STABLE" && !mapStatus.startsWith("PLOT FAIL"))
              ? "bg-zinc-950/20 backdrop-blur-[7px] border-cyan-500/20"
              : "bg-zinc-950/98 border-zinc-900"
          }`}
        >
          {/* Header of downwards console */}
          <div className="px-4 py-2 border-b border-zinc-900/60 bg-zinc-950/70 shrink-0 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center space-x-2">
              <span className={`w-2 h-2 rounded-full ${isLoading || isTyping ? activeTheme.accentBg + " shadow-[0_0_10px_" + activeTheme.accentBg.replace('bg-', '') + "] animate-pulse" : "bg-zinc-700"} inline-block transition-all duration-500`} />
              <h2 className={`text-[9px] md:text-[10px] uppercase tracking-widest ${isLoading || isTyping ? activeTheme.accentText : "text-zinc-500"} font-mono transition-all duration-500`}>
                {isLoading || isTyping ? "// CRNI CORE ACTIVE" : "// COGNITIVE LOG ENGINE"}
              </h2>
            </div>
            
            <div className="flex items-center gap-4 ml-auto">
              {/* Mini voice selection preset */}
              <div className="flex items-center gap-1.5">
                <span className="text-[8px] text-zinc-500 uppercase font-mono tracking-widest hidden sm:inline">VOICE:</span>
                <select
                  value={voicePreset}
                  onChange={(e: any) => setVoicePreset(e.target.value as any)}
                  className="bg-zinc-900 text-zinc-300 text-[8.5px] border border-zinc-800 font-mono rounded px-1 py-0.5 outline-none cursor-pointer hover:border-cyan-500 transition-all font-bold"
                >
                  <option value="FRIDAY_SOOTHING">CRNI (SOOTHING F)</option>
                  <option value="CRNI_SOOTHING_M">CRNI (SOOTHING M)</option>
                  <option value="CRNI_CYBER_03">CYBER AMBIENT</option>
                </select>
              </div>

              {/* Equalizer animation graphics */}
              <div className="flex gap-[1.5px] items-end h-3.5" title="Real-time speech equalizer monitor">
                <div
                  className={`w-[2px] bg-cyan-500 ${
                    isSpeaking || isLoading || isListening ? "animate-voice-pulse h-[80%]" : "h-[30%]"
                  }`}
                  style={{ animationDelay: "0ms" }}
                />
                <div
                  className={`w-[2px] bg-cyan-400 ${
                    isSpeaking || isLoading || isListening ? "animate-voice-pulse h-[60%]" : "h-[15%]"
                  }`}
                  style={{ animationDelay: "150ms" }}
                />
                <div
                  className={`w-[2px] bg-cyan-600 ${
                    isSpeaking || isLoading || isListening ? "animate-voice-pulse h-[90%]" : "h-[45%]"
                  }`}
                  style={{ animationDelay: "300ms" }}
                />
              </div>

              {/* Telemetry status feed */}
              <div className="flex items-center space-x-1.5">
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping" />
                <span className="text-[8px] font-mono text-zinc-400 uppercase tracking-widest hidden sm:inline">
                  {routingState.to ? "TRACKING ACTIVE" : "STABLE FEED"}
                </span>
              </div>
            </div>
          </div>

          {/* Chat scrolling log with will-change-transform for buttery smooth 60fps scrolling performance */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 select-text scrollbar-thin will-change-transform">
            <AnimatePresence initial={false}>
              {messages.map((msg) => (
                <motion.div
                  key={msg.id}
                  initial={
                    msg.sender === "user"
                      ? { opacity: 0, x: 25, y: 8, scale: 0.96 }
                      : { opacity: 0, x: -25, y: 8, scale: 0.96 }
                  }
                  animate={{ opacity: 1, x: 0, y: 0, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{
                    type: "spring",
                    stiffness: 280,
                    damping: 22,
                    mass: 0.85,
                  }}
                  className="space-y-1"
                >
                  {msg.sender === "user" ? (
                    /* Custom geometric user bubble with left industrial bar */
                    <div className="space-y-0.5 max-w-[90%] md:max-w-[75%] ml-auto group">
                      <div className="glass-panel p-4 border-l-2 border-zinc-700/40 rounded-2xl rounded-tr-none flex flex-col shadow-xl transition-all duration-500 group-hover:border-zinc-500/60">
                        <p className={`text-[8px] ${activeTheme.accentText} tracking-[0.2em] font-mono mb-1.5 uppercase opacity-60`}>// USER_COMMAND_PRIMARY</p>
                        <p className="text-[13px] md:text-sm font-sans italic text-zinc-300 leading-relaxed">{msg.text}</p>
                      </div>
                      <p className="text-[7.5px] text-zinc-650 text-right font-mono uppercase tracking-widest mt-1 opacity-40">{msg.timestamp}</p>
                    </div>
                  ) : (
                    /* Custom geometric AI response sheet with 60fps spring transitions */
                    <div className="space-y-0.5 max-w-[90%] md:max-w-[75%] relative">
                      <div className={`glass-panel p-4 border-l-2 ${activeTheme.accentBorder} rounded-2xl rounded-tl-none flex flex-col shadow-2xl relative overflow-hidden group`}>
                        {(isLoading || isTyping) && msg.id === messages[messages.length - 1].id && msg.sender === "crni" && (
                          <div className={`absolute top-0 left-0 right-0 h-[1px] ${activeTheme.accentBg} opacity-20 animate-pulse`} />
                        )}
                        <p className={`text-[8px] ${msg.isLiveTyping && isTyping ? activeTheme.accentText + " text-glow" : "text-zinc-500"} tracking-[0.2em] font-mono mb-2 uppercase transition-all duration-700`}>
                          {msg.isLiveTyping && isTyping ? "// NEURAL_STREAM_ACTIVE" : "// CORE_ASSISTANT_RELAY"}
                        </p>
                        <div className={`text-[13px] md:text-sm font-sans ${msg.isLiveTyping && isTyping ? "text-white" : "text-zinc-200"} leading-relaxed whitespace-pre-wrap transition-colors duration-700`}>
                          {msg.isLiveTyping && isTyping ? (
                            <TypingEffect 
                              text={msg.text} 
                              onComplete={() => {
                                setIsTyping(false);
                                setMapStatus("SYSTEM: STABLE");
                                // We don't remove isLiveTyping yet to avoid a flash, 
                                // but the state change will handle the rest
                              }} 
                            />
                          ) : (
                            msg.text
                          )}
                        </div>

                        {/* Travel Intelligence Modules */}
                        {msg.travelIntel && (
                          <div className="mt-3 space-y-3 border-t border-zinc-800/80 pt-3">
                            <p className="text-[8px] text-emerald-500 font-mono tracking-widest uppercase mb-2 animate-pulse">// TRAVEL INTELLIGENCE FEED ACTIVE</p>
                            
                            {/* Flights */}
                            {msg.travelIntel.flights && msg.travelIntel.flights.length > 0 && (
                              <div className="space-y-1.5">
                                <span className="flex items-center gap-1.5 text-[7px] text-zinc-500 font-bold uppercase tracking-wider">
                                  <Plane className="h-2.5 w-2.5" /> FLIGHT VECTORS
                                </span>
                                <div className="grid grid-cols-1 gap-1.5">
                                  {msg.travelIntel.flights.map((item) => (
                                    <div key={item.id} className="p-2.5 bg-zinc-950/40 border border-zinc-850 rounded flex flex-col hover:border-cyan-500/30 transition-all">
                                      <div className="flex justify-between items-start">
                                        <span className="text-[9px] font-bold text-zinc-200">{item.title}</span>
                                        <span className="text-[9px] font-bold text-emerald-400">{item.cost}</span>
                                      </div>
                                      <span className="text-[8px] text-zinc-500 mt-0.5">{item.details}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}

                            {/* Transport */}
                            {msg.travelIntel.transport && msg.travelIntel.transport.length > 0 && (
                              <div className="space-y-1.5">
                                <span className="flex items-center gap-1.5 text-[7px] text-zinc-500 font-bold uppercase tracking-wider">
                                  <Car className="h-2.5 w-2.5" /> GROUND TRANSIT
                                </span>
                                <div className="grid grid-cols-1 gap-1.5">
                                  {msg.travelIntel.transport.map((item) => (
                                    <div key={item.id} className="p-2.5 bg-zinc-950/40 border border-zinc-850 rounded flex flex-col hover:border-cyan-500/30 transition-all">
                                      <div className="flex justify-between items-start">
                                        <span className="text-[9px] font-bold text-zinc-200">{item.title}</span>
                                        <span className="text-[9px] font-bold text-emerald-400">{item.cost}</span>
                                      </div>
                                      <span className="text-[8px] text-zinc-500 mt-0.5">{item.details}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}

                            {/* Hotels */}
                            {msg.travelIntel.hotels && msg.travelIntel.hotels.length > 0 && (
                              <div className="space-y-1.5">
                                <span className="flex items-center gap-1.5 text-[7px] text-zinc-500 font-bold uppercase tracking-wider">
                                  <Hotel className="h-2.5 w-2.5" /> ACCOMMODATION DATA
                                </span>
                                <div className="grid grid-cols-1 gap-1.5">
                                  {msg.travelIntel.hotels.map((item) => (
                                    <div key={item.id} className="p-2.5 bg-zinc-950/40 border border-zinc-850 rounded flex flex-col hover:border-cyan-500/30 transition-all">
                                      <div className="flex justify-between items-start">
                                        <span className="text-[9px] font-bold text-zinc-200">{item.title}</span>
                                        <span className="text-[9px] font-bold text-emerald-400">{item.cost}</span>
                                      </div>
                                      <span className="text-[8px] text-zinc-500 mt-0.5">{item.details}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        )}

                        {/* Distance coordinate calculation trigger attachments */}
                        {msg.mapAction && msg.mapAction.type !== "none" && (
                          <div className={`mt-2 text-[9px] font-mono flex items-center justify-between ${activeTheme.accentText} border-t border-zinc-800/80 pt-2.5`}>
                            <span className="flex items-center space-x-1 uppercase tracking-widest text-[8px]">
                              <Zap className={`h-3 w-3 ${activeTheme.accentText} shrink-0`} />
                              <span>MAP ACTION: {msg.mapAction.type}</span>
                            </span>
                            <button
                              onClick={() => applyMapAction(msg.mapAction)}
                              className={`text-[8.5px] px-2 py-0.5 ${activeTheme.accentBgMuted} hover:bg-zinc-950 ${activeTheme.accentTextMuted} border ${activeTheme.accentBorderLight} rounded transition-all tracking-wider font-mono uppercase cursor-pointer`}
                            >
                              PLOT MAP
                            </button>
                          </div>
                        )}
                      </div>
                      <p className="text-[7.5px] text-zinc-650 font-mono uppercase tracking-wider">{msg.timestamp}</p>
                    </div>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>

            {/* Simulated server response lag loading animations removed for cinematic typing flow */}
            <div ref={chatBottomRef} />
          </div>

          <AnimatePresence mode="wait">
            {!isLoading && !isTyping && (
              <motion.div 
                initial={{ opacity: 0, y: 40, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 60, scale: 0.95 }}
                transition={{ 
                  duration: 0.6, 
                  ease: [0.16, 1, 0.3, 1] // Custom quint ease-out for premium feel
                }}
                className="p-4 border-t border-zinc-900/40 glass-panel shrink-0 z-10 relative"
              >
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-[1px] bg-gradient-to-r from-transparent via-zinc-800 to-transparent" />
                
                <form onSubmit={(e) => handleSubmit(e)} className="flex items-center gap-3 max-w-5xl mx-auto w-full group">
                  {/* Inline Microphone Button */}
                  <button
                    type="button"
                    onClick={toggleListening}
                    className={`p-3 rounded-full border transition-all duration-500 flex items-center justify-center shrink-0 cursor-pointer ${
                      isListening
                        ? "bg-red-500/10 border-red-500/50 text-red-500 shadow-[0_0_20px_rgba(239,68,68,0.2)]"
                        : `bg-zinc-900/50 border-zinc-800/50 text-zinc-500 hover:text-zinc-300 hover:border-zinc-700/50`
                    }`}
                  >
                    {isListening ? (
                      <div className="relative">
                        <MicOff className="h-4 w-4" />
                        <div className="absolute inset-0 animate-ping opacity-20"><MicOff className="h-4 w-4" /></div>
                      </div>
                    ) : (
                      <Mic className="h-4 w-4" />
                    )}
                  </button>

                  <div className="flex-1 relative">
                    <input
                      type="text"
                      placeholder={isListening ? "// TRANSCRIBING DATA STREAM..." : "Initiate tactical query or system command..."}
                      className={`w-full bg-zinc-900/40 border border-zinc-800/50 hover:border-zinc-700/40 ${activeTheme.accentRing} text-[13px] rounded-xl px-4 py-3 text-zinc-200 placeholder-zinc-600 focus:outline-none transition-all font-sans tracking-wide`}
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      disabled={isListening}
                    />
                    <div className={`absolute bottom-0 left-4 right-4 h-[1px] bg-gradient-to-r from-transparent via-zinc-400/10 to-transparent transition-opacity duration-500 group-focus-within:opacity-100 opacity-0`} />
                  </div>

                  <button
                    type="submit"
                    disabled={!inputText.trim() || isLoading}
                    className={`p-3 rounded-full bg-zinc-900/50 border border-zinc-800/50 text-zinc-500 transition-all duration-300 disabled:opacity-10 flex items-center justify-center shrink-0 cursor-pointer ${inputText.trim() ? activeTheme.accentText + " " + activeTheme.hoverBorder : ""}`}
                  >
                    <Send className="h-4 w-4" />
                  </button>
                </form>
              </motion.div>
            )}
          </AnimatePresence>
        </section>

      </main>

    </div>
  );
}
