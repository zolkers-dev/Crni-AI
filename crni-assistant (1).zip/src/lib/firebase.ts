import { initializeApp, getApps, getApp } from "firebase/app";
import {
  getAuth,
  GoogleAuthProvider,
  GithubAuthProvider,
  signInWithPopup,
  signOut,
  User,
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword
} from "firebase/auth";
import {
  initializeFirestore,
  collection,
  doc,
  setDoc,
  getDocs,
  query,
  where,
  orderBy,
  limit,
  Timestamp,
  addDoc,
  serverTimestamp,
  getDoc,
  updateDoc,
  deleteDoc
} from "firebase/firestore";
import firebaseConfig from "../../firebase-applet-config.json";
import { ChatSession, ChatHistoryItem, UserPreferences } from "../types";

// Check if credentials are live or placeholder
export const isFirebaseLive = 
  firebaseConfig &&
  firebaseConfig.apiKey &&
  !firebaseConfig.apiKey.includes("MockKey");

let firebaseApp;
let authInstance: any = null;

// Initialize Firebase if live, otherwise mock
if (isFirebaseLive) {
  try {
    firebaseApp = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    authInstance = getAuth(firebaseApp);
  } catch (err) {
    console.warn("Failed to initialize live Firebase, returning mock context:", err);
  }
}

// Global Providers
export const googleProvider = new GoogleAuthProvider();
export const githubProvider = new GithubAuthProvider();

export const auth = authInstance;
export const db = isFirebaseLive && firebaseApp 
  ? initializeFirestore(firebaseApp, { 
      experimentalForceLongPolling: true 
    }, firebaseConfig.firestoreDatabaseId) 
  : null;

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth?.currentUser?.uid,
      email: auth?.currentUser?.email,
      emailVerified: auth?.currentUser?.emailVerified,
      isAnonymous: auth?.currentUser?.isAnonymous,
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Auth Profile Interface
export interface AuthUserProfile {
  uid: string;
  displayName: string | null;
  email: string | null;
  photoURL: string | null;
  providerId: string;
}

// Listen to auth changes
export function subscribeToAuth(callback: (user: AuthUserProfile | null) => void) {
  if (isFirebaseLive && auth) {
    return onAuthStateChanged(auth, (firebaseUser) => {
      if (firebaseUser) {
        callback({
          uid: firebaseUser.uid,
          displayName: firebaseUser.displayName,
          email: firebaseUser.email,
          photoURL: firebaseUser.photoURL,
          providerId: firebaseUser.providerData[0]?.providerId || "google.com"
        });
      } else {
        callback(null);
      }
    });
  } else {
    // Return unsubscribe for mock
    const localUser = localStorage.getItem("crni_agent_user");
    if (localUser) {
      try {
        callback(JSON.parse(localUser));
      } catch {
        callback(null);
      }
    } else {
      callback(null);
    }
    return () => {};
  }
}

// Sign in with Google Popup
export async function signInWithGoogle(): Promise<AuthUserProfile> {
  if (isFirebaseLive && auth) {
    const result = await signInWithPopup(auth, googleProvider);
    const profile: AuthUserProfile = {
      uid: result.user.uid,
      displayName: result.user.displayName,
      email: result.user.email,
      photoURL: result.user.photoURL,
      providerId: "google.com"
    };
    return profile;
  } else {
    // Simulated Google login
    const profile: AuthUserProfile = {
      uid: "google-mock-agent-77",
      displayName: "Creator Google Agent",
      email: "master.agent@google.com",
      photoURL: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80",
      providerId: "google.com"
    };
    localStorage.setItem("crni_agent_user", JSON.stringify(profile));
    return profile;
  }
}

// Sign in with GitHub Popup
export async function signInWithGithub(): Promise<AuthUserProfile> {
  if (isFirebaseLive && auth) {
    const result = await signInWithPopup(auth, githubProvider);
    const profile: AuthUserProfile = {
      uid: result.user.uid,
      displayName: result.user.displayName,
      email: result.user.email,
      photoURL: result.user.photoURL,
      providerId: "github.com"
    };
    return profile;
  } else {
    // Simulated GitHub login
    const profile: AuthUserProfile = {
      uid: "github-mock-agent-56",
      displayName: "Stark GitHub Core",
      email: "tony.stark@github.com",
      photoURL: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80",
      providerId: "github.com"
    };
    localStorage.setItem("crni_agent_user", JSON.stringify(profile));
    return profile;
  }
}

// Sign Out
export async function logOut(): Promise<void> {
  if (isFirebaseLive && auth) {
    await signOut(auth);
  } else {
    localStorage.removeItem("crni_agent_user");
  }
}

// Sign In with Email/Password
export async function signInWithEmail(email: string, pass: string): Promise<AuthUserProfile> {
  if (isFirebaseLive && auth) {
    const result = await signInWithEmailAndPassword(auth, email, pass);
    return {
      uid: result.user.uid,
      displayName: result.user.displayName || email.split("@")[0],
      email: result.user.email,
      photoURL: result.user.photoURL,
      providerId: "password"
    };
  } else {
    throw new Error("Live Firebase not active for email login.");
  }
}

// Sign Up with Email/Password
export async function signUpWithEmail(email: string, pass: string): Promise<AuthUserProfile> {
  if (isFirebaseLive && auth) {
    const result = await createUserWithEmailAndPassword(auth, email, pass);
    return {
      uid: result.user.uid,
      displayName: email.split("@")[0],
      email: result.user.email,
      photoURL: null,
      providerId: "password"
    };
  } else {
    throw new Error("Live Firebase not active for email signup.");
  }
}

// --- UTILITIES ---

/**
 * Recursively removes undefined values from an object and replaces them with null.
 * Firestore does not support undefined values.
 */
function sanitizeData(data: any): any {
  if (data === undefined) return null;
  if (data === null || typeof data !== 'object') return data;
  
  // Handle Firestore Timestamps or other special objects if needed
  if (data instanceof Date) return data;
  
  if (Array.isArray(data)) {
    return data.map(sanitizeData);
  }

  const sanitized: any = {};
  for (const key in data) {
    if (Object.prototype.hasOwnProperty.call(data, key)) {
      const value = data[key];
      // Skip undefined or convert to null
      if (value !== undefined) {
        sanitized[key] = sanitizeData(value);
      } else {
        sanitized[key] = null;
      }
    }
  }
  return sanitized;
}

// --- USER PREFERENCES ---

export async function saveUserPreferences(userId: string, prefs: UserPreferences): Promise<void> {
  if (!db || !isFirebaseLive) return;
  const path = `user_preferences/${userId}`;
  const prefRef = doc(db, path);
  try {
    await setDoc(prefRef, {
      ...sanitizeData(prefs),
      updatedAt: serverTimestamp()
    }, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function getUserPreferences(userId: string): Promise<UserPreferences | null> {
  if (!db || !isFirebaseLive) return null;
  const path = `user_preferences/${userId}`;
  const prefRef = doc(db, path);
  try {
    const snap = await getDoc(prefRef);
    if (snap.exists()) {
      return snap.data() as UserPreferences;
    }
    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
    return null;
  }
}
