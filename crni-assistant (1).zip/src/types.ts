export interface MapAction {
  type: "show_location" | "calculate_route" | "none";
  fromName: string;
  toName: string;
}

export interface TravelItem {
  id: string;
  type: string;
  title: string;
  details: string;
  cost: string;
}

export interface CrniResponse {
  reply: string;
  mapAction: MapAction;
  travelIntel?: {
    flights?: TravelItem[];
    transport?: TravelItem[];
    hotels?: TravelItem[];
  };
}

export interface ChatMessage {
  id: string;
  sender: "user" | "crni";
  text: string;
  timestamp: string;
  mapAction?: MapAction;
  travelIntel?: CrniResponse["travelIntel"];
  isLiveTyping?: boolean;
}

export interface GeocodedLocation {
  name: string;
  coords: [number, number];
}

export interface RoutingState {
  from: GeocodedLocation | null;
  to: GeocodedLocation | null;
  distanceKm: number | null;
}

export interface SavedLocation {
  id: string;
  name: string;
  coords: [number, number];
  timestamp: number;
}

export interface UserPreferences {
  currency: string;
}

export interface ChatSession {
  id: string;
  userId: string;
  title: string;
  lastMessageSnippet: string;
  timestamp: number;
}

export interface ChatHistoryItem {
  id: string;
  text: string;
  sender: "user" | "crni";
  timestamp: string;
  createdAt?: any;
  mapAction?: CrniResponse["mapAction"];
  travelIntel?: CrniResponse["travelIntel"];
}
