import express from "express";
import path from "path";
import { GoogleGenAI, Type } from "@google/genai";

const app = express();
const PORT = 3000;

app.use(express.json());

// Health check endpoint for Cloud Run
app.get("/api/health", (req, res) => {
  res.json({ status: "healthy", timestamp: new Date().toISOString() });
});

// Lazy-initialized Gemini Client
let geminiClient: GoogleGenAI | null = null;

function getGemini(): GoogleGenAI {
  if (!geminiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("GEMINI_API_KEY is not configured.");
    }
    geminiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return geminiClient;
}

// Response schema definition
const responseSchema: any = {
  type: Type.OBJECT,
  properties: {
    reply: {
      type: Type.STRING,
      description: "Conversational voice response. Warmly addresses the user as 'master' and direct answers.",
    },
    mapAction: {
      type: Type.OBJECT,
      properties: {
        type: {
          type: Type.STRING,
          description: "Must be 'show_location', 'calculate_route', or 'none'.",
        },
        fromName: { type: Type.STRING },
        toName: { type: Type.STRING },
      },
      required: ["type", "fromName", "toName"],
    },
    travelIntel: {
      type: Type.OBJECT,
      properties: {
        flights: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { id: { type: Type.STRING }, title: { type: Type.STRING }, details: { type: Type.STRING }, cost: { type: Type.STRING } }, required: ["id", "title", "details", "cost"] } },
        transport: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { id: { type: Type.STRING }, title: { type: Type.STRING }, details: { type: Type.STRING }, cost: { type: Type.STRING } }, required: ["id", "title", "details", "cost"] } },
        hotels: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { id: { type: Type.STRING }, title: { type: Type.STRING }, details: { type: Type.STRING }, cost: { type: Type.STRING } }, required: ["id", "title", "details", "cost"] } },
      },
    },
  },
  required: ["reply", "mapAction"],
};

// API Endpoint for precise road routing via Open Source Routing Machine (OSRM)
app.post("/api/route", async (req, res) => {
  try {
    const { origin, destination } = req.body;
    
    if (!origin || !destination) {
      return res.status(400).json({ error: "Origin and destination are required." });
    }

    // OSRM expects coordinates in lng,lat format
    const start = typeof origin === "object" ? `${origin.lng},${origin.lat}` : origin;
    const end = typeof destination === "object" ? `${destination.lng},${destination.lat}` : destination;

    // Use OSRM public demo instance (Note: For high volume, a private instance is recommended)
    const url = `https://router.project-osrm.org/route/v1/driving/${start};${end}?overview=full&geometries=polyline`;
    
    const response = await fetch(url);
    const data = await response.json();

    if (data.code !== "Ok") {
      throw new Error(data.message || "OSRM Routing Error");
    }

    // Adapt OSRM response to match the expected tactical format
    const tacticalData = {
      routes: data.routes.map((r: any) => ({
        polyline: {
          encodedPolyline: r.geometry
        },
        distanceMeters: r.distance,
        duration: `${r.duration}s`
      }))
    };

    res.json(tacticalData);
  } catch (error: any) {
    console.error("Error in /api/route:", error);
    res.status(500).json({ error: error.message || "Failed to fetch tactical road route." });
  }
});

// API Endpoint for chatting with Crni AI powered by Gemini
app.post("/api/chat", async (req, res) => {
  try {
    const { message, currency, history } = req.body;
    if (!message) {
      res.status(400).json({ error: "Message is required" });
      return;
    }

    // Retrieve Gemini API Key and validate
    const geminiKey = process.env.GEMINI_API_KEY;
    if (!geminiKey) {
      res.json({
        reply: "Welcome to my core brain, Master. I detected that GEMINI_API_KEY is not yet configured. Please click Settings > Secrets on the top-right of the AI Studio workspace, add 'GEMINI_API_KEY' with your Google Gemini API key, and I will be fully online to process your coordinates.",
        mapAction: { type: "none", fromName: "", toName: "" }
      });
      return;
    }

    const ai = getGemini();

    const systemInstruction = 
      "Your name is Crni (CRNI Core Engine). You are a highly intelligent, real-time interactive tactical companion speaking to your master, styled as an exceptionally confident, articulate, and sophisticated digital supervisor.\n" +
      `CURRENCY PREFERENCE: The master's preferred currency is ${currency || "USD"}. ALWAYS output costs in this currency if specified.\n` +
      "CRITICAL CONCISENESS & SPEED INSTRUCTION: Keep your verbal 'reply' extremely brief (under 35 words). Put detailed data like travel costs into the structured 'travelIntel' object.\n" +
      "Your tone is unshakeably confident, authoritative, polite, and perfectly poised. Address the user with absolute loyalty as 'Master', 'Sir', or 'my Creator'.\n" +
      "TRAVEL INTELLIGENCE: If the user asks for travel, routes, or trips between locations (e.g. 'India to America'), you MUST provide estimated flights, local transport, and hotel options in the 'travelIntel' field. Use your internal knowledge base to provide realistic (though estimated) market prices and options.\n" +
      "If the user asks map or routing or distance questions, identify the places and set mapAction accordingly.\n\n" +
      "CRITICAL: Always format your reply as a valid JSON object matching the provided schema. Do not output anything outside of the JSON object.";

    // Convert history format to Gemini format and ensure roles alternate (Gemini requirement)
    let historyParts = [];
    if (history && Array.isArray(history)) {
      let lastRole = "";
      for (const h of history) {
        const text = h.text || h.content || (h.parts?.[0]?.text) || "";
        if (!text) continue;
        
        let role = h.role === "model" || h.role === "assistant" ? "model" : "user";
        
        // Skip consecutive same roles to avoid Gemini API errors
        if (role === lastRole) continue;
        
        historyParts.push({
          role: role,
          parts: [{ text: text }]
        });
        lastRole = role;
      }
    }

    const modelsToTry = [
      "gemini-3.5-flash",
      "gemini-flash-latest"
    ];
    let result = null;
    let lastError = null;

    for (const modelName of modelsToTry) {
      try {
        const chatResult = await ai.models.generateContent({
          model: modelName,
          contents: [...historyParts, { role: "user", parts: [{ text: message }] }],
          config: {
            systemInstruction: systemInstruction,
            responseMimeType: "application/json",
            responseSchema: responseSchema,
            temperature: 0.1,
          },
        });
        
        if (chatResult && chatResult.text) {
          result = chatResult.text;
          break;
        }
      } catch (err: any) {
        lastError = err;
        const lowErr = (err.message || String(err)).toLowerCase();
        if (lowErr.includes("api_key") || lowErr.includes("key") || lowErr.includes("unauthorized") || lowErr.includes("invalid argument")) {
          throw err;
        }
      }
    }

    if (!result) {
      throw lastError || new Error("All model clusters are currently offline.");
    }

    const parsed = JSON.parse(result.trim());
    res.json(parsed);

  } catch (error: any) {
    console.error("Error in /api/chat:", error);
    const errStr = error.message || String(error);
    let replyMessage = `Master, there was an issue connecting to my core brain: ${errStr}. Please ensure the system setup is correct.`;

    if (
      errStr.includes("429") || 
      errStr.toLowerCase().includes("quota") || 
      errStr.includes("RESOURCE_EXHAUSTED") || 
      errStr.toLowerCase().includes("rate limit")
    ) {
      replyMessage = "Master, my core neural synapse (Gemini API) has exceeded its rate limit or free-tier quota. Please wait about 60 seconds for the cooldown, or check your API billing & key configurations in Settings to restore full tactical capacity.";
    } else if (
      errStr.toLowerCase().includes("key") || 
      errStr.toLowerCase().includes("api_key") || 
      errStr.toLowerCase().includes("unauthorized") || 
      errStr.toLowerCase().includes("api key")
    ) {
      replyMessage = "Master, there is an issue with the GEMINI_API_KEY. Please verify that your API key is correctly entered and has permission to access Gemini services under Settings > Secrets.";
    }

    res.status(500).json({
      reply: replyMessage,
      mapAction: { type: "none", fromName: "", toName: "" }
    });
  }
});

// Vite Middleware & production static assets serving
async function startServer() {
  try {
    const isProd = process.env.NODE_ENV === "production";
    
    if (!isProd) {
      console.log("Starting in DEVELOPMENT mode with Vite middleware...");
      try {
        const { createServer } = await import("vite");
        const vite = await createServer({
          server: { middlewareMode: true },
          appType: "spa",
        });
        app.use(vite.middlewares);
        console.log("Vite middleware integrated successfully.");
      } catch (viteErr) {
        console.error("Failed to load Vite middleware in development:", viteErr);
      }
    } else {
      console.log("Starting in PRODUCTION mode...");
      // For Node running dist/server.cjs, __dirname is the dist folder itself.
      const distPath = path.resolve(__dirname);
      console.log(`[SYS_BOOT] Assets directory: ${distPath}`);
      
      // Serve static assets
      app.use(express.static(distPath, {
        index: false,
        maxAge: "1d"
      }));

      // SPA fallback
      app.get("*", (req, res, next) => {
        if (req.path.startsWith("/api/")) return next();
        res.sendFile(path.join(distPath, "index.html"), (err) => {
          if (err) res.status(500).send("Static asset relay failure.");
        });
      });
    }

    app.listen(PORT, "0.0.0.0", () => {
      console.log(`Server listening on port ${PORT}`);
    });
  } catch (err) {
    console.error("CRITICAL: Strategic failure during server initialization:", err);
    process.exit(1);
  }
}

startServer().catch(err => {
  console.error("FATAL: Unhandled rejection during neural link startup:", err);
  process.exit(1);
});
